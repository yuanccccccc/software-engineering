from flask import Flask, jsonify
from flask_cors import CORS
from data_loader import read_all_water_quality
from collections import Counter

app = Flask(__name__)
CORS(app)  # 允许跨域

@app.route('/api/sankey')
def sankey_data():
    df = read_all_water_quality()

    # 仅保留关键字段 + 去除非法项
    df = df[df["水质类别"] != "*"]
    df = df[["省份", "流域", "水质类别"]].dropna()

    links_raw = []

    for _, row in df.iterrows():
        links_raw.append((row["省份"], row["流域"]))
        links_raw.append((row["流域"], row["水质类别"]))

    # 聚合成计数
    link_counts = Counter(links_raw)
    links = [{"source": s, "target": t, "value": v} for (s, t), v in link_counts.items()]
    nodes = list({n for s, t in link_counts for n in (s, t)})

    return jsonify({
        "nodes": [{"name": name} for name in nodes],
        "links": links
    })


# 原来的 /api/water 接口也保留
@app.route('/api/water')
def water_data():
    df = read_all_water_quality()
    df = df.sort_values(by="监测时间")
    return jsonify(df.to_dict(orient='records'))


if __name__ == '__main__':
    app.run(debug=True)
